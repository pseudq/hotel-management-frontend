// Add this file to your public directory
window.env = {
  REACT_APP_API_URL: "REACT_APP_API_URL_PLACEHOLDER",
};
