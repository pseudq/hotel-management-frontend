import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { CssBaseline, Box } from "@mui/material";
import Sidebar from "./components/Sidebar";
import Dashboard from "./components/Dashboard";
import RoomManagement from "./components/RoomManagement";
import RoomTypeManagement from "./components/RoomTypeManagement";
import CustomerManagement from "./components/CustomerManagement";
import BookingManagement from "./components/BookingManagement";
import ServiceManagement from "./components/ServiceManagement";
import InvoiceManagement from "./components/InvoiceManagement";

function App() {
  return (
    <Router>
      <CssBaseline />
      <Box sx={{ display: "flex" }}>
        <Sidebar />
        <Box
          component="main"
          sx={{ flexGrow: 1, bgcolor: "background.default", p: 3 }}
        >
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/rooms" element={<RoomManagement />} />
            <Route path="/room-types" element={<RoomTypeManagement />} />
            <Route path="/customers" element={<CustomerManagement />} />
            <Route path="/bookings" element={<BookingManagement />} />
            <Route path="/services" element={<ServiceManagement />} />
            <Route path="/invoices" element={<InvoiceManagement />} />
          </Routes>
        </Box>
      </Box>
    </Router>
  );
}

export default App;
