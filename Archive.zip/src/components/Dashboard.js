import React, { useState, useEffect } from "react";
import {
  Grid,
  Card,
  CardContent,
  Typography,
  Button,
  Menu,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
} from "@mui/material";
import {
  getRooms,
  updateRoom,
  createBooking,
  checkoutBooking,
  calculatePrice,
  createInvoice,
} from "../apiService";

const Dashboard = () => {
  const [rooms, setRooms] = useState([]);
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [checkInDialogOpen, setCheckInDialogOpen] = useState(false);
  const [checkOutDialogOpen, setCheckOutDialogOpen] = useState(false);
  const [checkInData, setCheckInData] = useState({
    khach_hang_id: "",
    phong_id: "",
    thoi_gian_vao: "",
    ghi_chu: "",
  });
  const [checkOutData, setCheckOutData] = useState(null);

  useEffect(() => {
    fetchRooms();
  }, []);

  const fetchRooms = async () => {
    try {
      console.log("Fetching rooms...");
      const response = await getRooms();
      console.log("Rooms fetched:", response.data);
      setRooms(response.data); // Cập nhật state với dữ liệu mới
    } catch (error) {
      console.error("Error fetching rooms:", error);
    }
  };

  const handleMenuOpen = (event, room) => {
    setAnchorEl(event.currentTarget);
    setSelectedRoom(room);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    setSelectedRoom(null);
  };

  const handleCheckInOpen = () => {
    setCheckInData({
      khach_hang_id: "",
      phong_id: selectedRoom.id,
      thoi_gian_vao: new Date().toISOString(),
      ghi_chu: "",
    });
    setCheckInDialogOpen(true);
    handleMenuClose();
  };

  const handleCheckInClose = () => {
    setCheckInDialogOpen(false);
  };

  const handleCheckInSubmit = async () => {
    try {
      console.log("Submitting check-in:", checkInData);

      // Tạo booking
      await createBooking(checkInData);

      // Cập nhật trạng thái phòng
      console.log("Updating room status...");
      await updateRoom(selectedRoom.id, {
        ...selectedRoom,
        trang_thai: "đang sử dụng",
      });

      console.log("Room status updated successfully.");
      fetchRooms(); // Làm mới danh sách phòng
    } catch (error) {
      console.error("Error during check-in:", error);
    } finally {
      handleCheckInClose();
    }
  };

  const handleCheckOutOpen = async () => {
    try {
      // Fetch price calculation data
      const response = await calculatePrice(selectedRoom.id);
      setCheckOutData(response.data);
      setCheckOutDialogOpen(true);
    } catch (error) {
      console.error("Error fetching check-out data:", error);
    } finally {
      handleMenuClose();
    }
  };

  const handleCheckOutClose = () => {
    setCheckOutDialogOpen(false);
  };

  const handleCheckOutSubmit = async () => {
    try {
      // Create an invoice
      const invoiceData = {
        dat_phong_id: selectedRoom.id,
        khach_hang_id: checkOutData.khach_hang_id,
        tong_tien_phong: checkOutData.tien_phong.tongTien,
        tong_tien_dich_vu: checkOutData.tien_dich_vu.tong_tien,
        tong_tien: checkOutData.tong_tien,
        trang_thai_thanh_toan: "chưa thanh toán",
      };
      await createInvoice(invoiceData);

      // Perform check-out
      await checkoutBooking(selectedRoom.id);

      // Update room status to "đang dọn"
      await updateRoom(selectedRoom.id, {
        ...selectedRoom,
        trang_thai: "đang dọn",
      });

      // Refresh room data
      fetchRooms();
    } catch (error) {
      console.error("Error during check-out:", error);
    } finally {
      handleCheckOutClose();
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "trống":
        return "#4caf50"; // Green
      case "đang sử dụng":
        return "#f44336"; // Red
      case "đang dọn":
        return "#ffeb3b"; // Yellow
      default:
        return "#e0e0e0"; // Gray
    }
  };

  return (
    <div>
      <Typography variant="h4" gutterBottom>
        Room Dashboard
      </Typography>
      <Grid container spacing={2}>
        {rooms.map((room) => {
          console.log(`Room ${room.so_phong} status: ${room.trang_thai}`);
          return (
            <Grid item xs={12} sm={6} md={4} lg={3} key={room.id}>
              <Card
                style={{
                  backgroundColor: getStatusColor(room.trang_thai),
                  color: "#000",
                }}
              >
                <CardContent>
                  <Typography variant="h5" gutterBottom>
                    Room {room.so_phong}
                  </Typography>
                  <Typography variant="body1">
                    Status: {room.trang_thai}
                  </Typography>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={(e) => handleMenuOpen(e, room)}
                    style={{ marginTop: "10px" }}
                  >
                    Actions
                  </Button>
                </CardContent>
              </Card>
            </Grid>
          );
        })}
      </Grid>
      {/* Action Menu */}
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
      >
        {selectedRoom?.trang_thai === "trống" && (
          <MenuItem onClick={handleCheckInOpen}>Check In</MenuItem>
        )}
        {selectedRoom?.trang_thai === "đang sử dụng" && (
          <MenuItem onClick={handleCheckOutOpen}>Check Out</MenuItem>
        )}
        {selectedRoom?.trang_thai === "đang dọn" && (
          <MenuItem
            onClick={async () => {
              try {
                await updateRoom(selectedRoom.id, {
                  ...selectedRoom,
                  trang_thai: "trống",
                });
                fetchRooms();
              } catch (error) {
                console.error("Error updating room status:", error);
              } finally {
                handleMenuClose();
              }
            }}
          >
            Mark as Cleaned
          </MenuItem>
        )}
      </Menu>
      {/* Check-In Dialog */}
      <Dialog open={checkInDialogOpen} onClose={handleCheckInClose}>
        <DialogTitle>Check In</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="Customer ID"
            name="khach_hang_id"
            value={checkInData.khach_hang_id}
            onChange={(e) =>
              setCheckInData({ ...checkInData, khach_hang_id: e.target.value })
            }
            margin="normal"
          />
          <TextField
            fullWidth
            label="Notes"
            name="ghi_chu"
            value={checkInData.ghi_chu}
            onChange={(e) =>
              setCheckInData({ ...checkInData, ghi_chu: e.target.value })
            }
            margin="normal"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCheckInClose}>Cancel</Button>
          <Button onClick={handleCheckInSubmit} color="primary">
            Submit
          </Button>
        </DialogActions>
      </Dialog>
      {/* Check-Out Dialog */}
      <Dialog open={checkOutDialogOpen} onClose={handleCheckOutClose}>
        <DialogTitle>Check Out</DialogTitle>
        <DialogContent>
          {checkOutData && (
            <>
              <Typography variant="body1">
                Total Room Charge: {checkOutData.tien_phong.tongTien} VND
              </Typography>
              <Typography variant="body1">
                Total Service Charge: {checkOutData.tien_dich_vu.tong_tien} VND
              </Typography>
              <Typography variant="body1">
                Total Amount: {checkOutData.tong_tien} VND
              </Typography>
              <Typography variant="body1">
                Time Used:{" "}
                {checkOutData.tien_phong.chiTiet.map((detail) => (
                  <div key={detail.loaiTinh}>
                    {detail.loaiTinh}: {detail.soLuong} x {detail.donGia} ={" "}
                    {detail.thanhTien} VND
                  </div>
                ))}
              </Typography>
            </>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCheckOutClose}>Cancel</Button>
          <Button onClick={handleCheckOutSubmit} color="primary">
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default Dashboard;
